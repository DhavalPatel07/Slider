# How to copy TEXT to Clipboard on Button-Click

A Pen created on CodePen.io. Original URL: [https://codepen.io/shaikmaqsood/pen/XmydxJ](https://codepen.io/shaikmaqsood/pen/XmydxJ).

Here I'm giving a  demo as to how to copy a Text directly to clicpboard without a Flash...